package com.blog.app.playloads;

import lombok.Data;

@Data
public class RoleDTO {
	private int id;
	private String name;
}