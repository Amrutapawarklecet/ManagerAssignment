package com.blog.app.playloads;

import lombok.Data;

//which is used for returning the token
@Data
public class JwtAuthResponse {

	private String token;
	
	private UserDTO userDto;
	
}